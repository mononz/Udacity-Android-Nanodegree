package it.jaschke.alexandria.api;

/**
 * Created by saj on 25/01/15.
 */
public interface Callback {
    public void onItemSelected(String ean);
}
